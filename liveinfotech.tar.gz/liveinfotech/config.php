<?php 

// $con_adv8 = mysqli_connect("infotechapp.com", "infotechapp", "eG7GN!A$3Lh9");
// mysqli_select_db($con_adv8, 'infotechapp');
// print_r($con_adv8);die;

// mysql_connect("infotechapp.com", "infotechapp", "eG7GN!A$3Lh9");
// $db = mysql_select_db('infotechapp');
// print_r($db);die;


?>
