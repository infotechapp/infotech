<!DOCTYPE html>
<head>
        <meta charset="utf-8">
        <title>Infotechapp</title>
        <meta name="description" content="ProUI is a Responsive Bootstrap Admin Template created by pixelcave and published on Themeforest.">
        <meta name="author" content="pixelcave">
        <meta name="robots" content="noindex, nofollow">
        <meta name="viewport" content="width=device-width,initial-scale=1.0,user-scalable=0">
      <?php include('common_css.php');?>  
	  
    </head>