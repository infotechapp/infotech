 <!-- Footer -->
            <footer class="text-muted text-center">
                <small>&copy; <?php echo date('Y'); ?> Infotechapp</a></small>
            </footer>
            <!-- END Footer -->