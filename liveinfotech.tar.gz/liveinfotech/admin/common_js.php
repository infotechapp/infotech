<script src="js/vendor/modernizr.min.js"></script>
<!-- jQuery, Bootstrap.js, jQuery plugins and Custom JS code -->
        <script src="js/vendor/jquery.min.js"></script>
        <script src="js/vendor/bootstrap.min.js"></script>
        <script src="js/plugins.js"></script>
        <script src="js/app.js"></script>
		<script src="js/pages/login.js"></script>
		<script src="js/pages/ecomDashboard.js"></script>
		 <script src="js/helpers/gmaps.min.js"></script>
		 <script src="js/pages/index.js"></script>
		 <script src="js/pages/formsValidation.js"></script>
		  <script src="js/pages/tablesDatatables.js"></script>