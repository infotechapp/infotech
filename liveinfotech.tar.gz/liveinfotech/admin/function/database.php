<?php 
error_reporting(E_ALL);
ini_set('display_errors', '1');
$conn = mysqli_connect("148.66.145.21", "infotechapp", "eG7GN!A$3Lh9");
mysqli_select_db($conn, 'infotechapp');

?>
