 <div class="col-md-3 success_msg">                            
	<div class="alert alert-danger alert-dismissable">
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
	<h4><i class="fa fa-times-circle"></i> Error</h4> Oh no! Update <a href="javascript:void(0)" class="alert-link">failed</a>!
	</div>
 </div>